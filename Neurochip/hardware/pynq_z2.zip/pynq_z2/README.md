# PYNQ Z2 Overlay v1

This directory contains the self-hosted hardware scaffold for the fixed
`snn_overlay_v1` runtime contract used by Neurochip and NeuroCNL.

The build flow is intentionally Linux-only:

1. Run `scripts/build_overlay.sh` on a Linux x86_64 host with Vivado 2022.x
   and Vitis HLS installed.
2. The scripted flow exports:
   - `build/out/snn_overlay.bit`
   - `build/out/snn_overlay.hwh`
   - `build/out/overlay_manifest.json`
3. Run `scripts/stage_overlay.sh` to copy those files into the canonical host
   staging directory at `../../overlay_staging/pynq_z2/`.

Overlay-v1 contract:

- Board part: `xc7z020clg400-1`
- Overlay ID: `snn_overlay_v1`
- Overlay version: `1.0.1`
- Neuron model: `LIF`
- Weight format: `int8` values in 32-bit MMIO words
- Max neurons: `256`
- Max synapses: `15360`
- Max populations: `2`

Layout:

- `hls/`: HLS kernel and HLS build Tcl
- `rtl/`: notes for any RTL wrapper or bridge logic
- `vivado/`: block-design and bitstream build Tcl
- `scripts/`: Linux host build/stage wrappers
- `build/out/`: generated artifacts; not tracked

The HLS engine models the feedforward compute core. The surrounding Vivado
design is responsible for PS7, DMA, clock/reset plumbing, and exporting the
final `.bit` and `.hwh` artifacts that the runtime installs on the board.
