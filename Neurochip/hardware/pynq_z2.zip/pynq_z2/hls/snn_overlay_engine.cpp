#include "snn_overlay_engine.hpp"

namespace {

float threshold_word_to_float(ap_uint<32> word) {
    union {
        unsigned int u32;
        float f32;
    } converter{};
    converter.u32 = word.to_uint();
    return converter.f32;
}

}  // namespace

void snn_overlay_engine(
    axis_stream_t& in_stream,
    axis_stream_t& out_stream,
    const ap_int<8> weights[OVERLAY_V1_MAX_SYNAPSES],
    const ap_uint<32> thresholds[OVERLAY_V1_MAX_POPULATIONS],
    unsigned int population_count,
    unsigned int input_neuron_count,
    unsigned int output_neuron_count,
    unsigned int timestep_count) {
#pragma HLS INTERFACE axis port=in_stream
#pragma HLS INTERFACE axis port=out_stream
#pragma HLS INTERFACE bram port=weights
#pragma HLS INTERFACE bram port=thresholds
#pragma HLS INTERFACE s_axilite port=population_count bundle=control
#pragma HLS INTERFACE s_axilite port=input_neuron_count bundle=control
#pragma HLS INTERFACE s_axilite port=output_neuron_count bundle=control
#pragma HLS INTERFACE s_axilite port=timestep_count bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    const unsigned int safe_population_count =
        (population_count == 0 || population_count > OVERLAY_V1_MAX_POPULATIONS)
            ? OVERLAY_V1_MAX_POPULATIONS
            : population_count;
    const unsigned int safe_input_count =
        (input_neuron_count > OVERLAY_V1_MAX_NEURONS) ? OVERLAY_V1_MAX_NEURONS : input_neuron_count;
    const unsigned int safe_output_count =
        (output_neuron_count > OVERLAY_V1_MAX_NEURONS) ? OVERLAY_V1_MAX_NEURONS : output_neuron_count;
    const float threshold =
        threshold_word_to_float(thresholds[(safe_population_count > 1) ? 1 : 0]);

    for (unsigned int timestep = 0; timestep < timestep_count; ++timestep) {
        for (unsigned int output_index = 0; output_index < safe_output_count; ++output_index) {
#pragma HLS PIPELINE II=1
            float membrane = 0.0f;
            for (unsigned int input_index = 0; input_index < safe_input_count; ++input_index) {
                axis_word_t input_word = in_stream.read();
                const unsigned int weight_index = output_index * safe_input_count + input_index;
                if (weight_index < OVERLAY_V1_MAX_SYNAPSES) {
                    membrane += (input_word.data != 0) ? static_cast<float>(weights[weight_index]) : 0.0f;
                }
            }

            axis_word_t output_word{};
            output_word.data = (membrane >= threshold) ? output_index : 0;
            output_word.keep = -1;
            output_word.strb = -1;
            output_word.last = (output_index + 1U == safe_output_count) ? 1 : 0;
            out_stream.write(output_word);
        }
    }
}
