#pragma once

#include <ap_axi_sdata.h>
#include <ap_int.h>
#include <hls_stream.h>

constexpr int OVERLAY_V1_MAX_NEURONS = 256;
constexpr int OVERLAY_V1_MAX_SYNAPSES = 15360;
constexpr int OVERLAY_V1_MAX_POPULATIONS = 2;

using axis_word_t = ap_axiu<32, 0, 0, 0>;
using axis_stream_t = hls::stream<axis_word_t>;

void snn_overlay_engine(
    axis_stream_t& in_stream,
    axis_stream_t& out_stream,
    const ap_int<8> weights[OVERLAY_V1_MAX_SYNAPSES],
    const ap_uint<32> thresholds[OVERLAY_V1_MAX_POPULATIONS],
    unsigned int population_count,
    unsigned int input_neuron_count,
    unsigned int output_neuron_count,
    unsigned int timestep_count);
