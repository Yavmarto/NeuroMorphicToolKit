#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${OUT_DIR:-$ROOT_DIR/build/out}"

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "This build flow requires a Linux x86_64 host with Vivado/Vitis HLS installed." >&2
  exit 1
fi

if ! command -v vitis_hls >/dev/null 2>&1; then
  echo "vitis_hls was not found in PATH." >&2
  exit 1
fi

if ! command -v vivado >/dev/null 2>&1; then
  echo "vivado was not found in PATH." >&2
  exit 1
fi

mkdir -p "$OUT_DIR"

echo "[pynq_z2] synthesizing HLS IP"
vitis_hls -f "$ROOT_DIR/hls/build_hls.tcl"

echo "[pynq_z2] building Vivado design"
vivado -mode batch -source "$ROOT_DIR/vivado/build_overlay.tcl" -tclargs "$OUT_DIR"

echo "[pynq_z2] overlay artifacts written to $OUT_DIR"
